package com.example.schedulingtasks;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SchedulingTasksApplicationTests {

	@Test
	public void contextLoads() {
	}

}
